<?php
	include("header.php");
?>
	hallo
<?php
	include("footer.php");
?>