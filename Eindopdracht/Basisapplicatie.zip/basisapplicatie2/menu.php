<ul id="menu">
		<li>
			<span>Films</span>
			<ul>
				<li><a href="<?php echo $root ?>/formulieren/films_nieuw.php">Nieuw..</a></li>
				<li>Overzicht</li>
			</ul>
		</li>
		<li>
			<span>Mensen</span>
			<ul>
				<li><a href="<?php echo $root ?>/formulieren/people_nieuw.php">Nieuw..</a></li>
				<li><a href="<?php echo $root ?>/overzichten/people.php">Overzicht</a></li>
			</ul>
		</li>
		<li>
			<span>Reviews</span>
			<ul>
				<li><a href="<?php echo $root ?>/formulieren/reviews_nieuw.php">Nieuw..</a></li>
				<li>Overzicht</li>
			</ul>
		</li>
		<li>
			<span>Rollen</span>
			<ul>
				<li><a href="<?php echo $root ?>/formulieren/roles_nieuw.php">Nieuw..</a></li>
				<li>Overzicht</li>
			</ul>
		</li>
</ul>